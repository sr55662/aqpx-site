# AQPX Site

Vite + React + Tailwind landing page (safe, no trade secrets).

## Run (PowerShell on Windows)
```powershell
cd .\aqpx-site
npm install
npm run dev
```

## Build
```powershell
npm run build
```

## Deploy to GitHub Pages
```powershell
npm run deploy
```
